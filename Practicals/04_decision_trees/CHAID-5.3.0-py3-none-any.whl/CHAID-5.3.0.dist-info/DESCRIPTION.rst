This package provides a python implementation of the Chi-Squared Automatic Inference Detection (CHAID) decision tree


